Contributions are always welcome😀!

- Fork the Template🍴
- Make Changes
- Push your commits to the forked repo
- Make a Pull Request
- Kindly wait for it to be merged
- If your PR is merged, don't forget to add yourself to the contributor list! [GUIDE](https://allcontributors.org/docs/en/bot/usage)
- Buy yourself a ☕ if it's merged🎉
